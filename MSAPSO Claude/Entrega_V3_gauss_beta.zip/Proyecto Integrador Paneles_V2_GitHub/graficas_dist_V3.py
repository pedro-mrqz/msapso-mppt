"""graficas_dist_V3.py — Figuras de la comparacion REINFORCE gaussiano vs Beta (V3).
Uso: python3 graficas_dist_V3.py   (lee resultados_V3/reinforce_dist_grid_V3.json; escribe resultados_V3/fig_*.png)"""
import sys, os, json, zlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import norm, beta as beta_dist
from pvsim_V2.reinforce_dist_V3 import ReinforceDistController, kappa_from_sigma
from pvsim_V2.msapso_V2 import MSAPSOController, run_scenario
from pvsim_V2.harness_V2 import build_scenarios, PASSES

AMBER, TEAL, GREEN, INK, GREY, RED = "#b3661a", "#2b5f63", "#3f7a4a", "#262320", "#8a8377", "#a8482f"
COL = {"gauss": TEAL, "beta": AMBER}
NAME = {"gauss": "Gaussiana", "beta": "Beta"}
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": GREY,
                     "axes.labelcolor": INK, "xtick.color": INK, "ytick.color": INK, "axes.titlesize": 9.5,
                     "figure.dpi": 140, "axes.grid": True, "grid.alpha": 0.25})
OUT = "resultados_V3"
JSON = f"{OUT}/reinforce_dist_grid_V3.json"
WAIT = 5e-3
ARM_LABEL = {"B-none": "B, sin baseline", "B-V": "B, baseline V", "A-none": "A, sin baseline",
             "A-V": "A, R − V", "A-Q": "A, R − Q̂", "A-QV": "A, Q̂ − V"}
ARMS = list(ARM_LABEL)


def fig_densidades(fname=f"{OUT}/fig_densidades_gauss_beta.png"):
    """Las dos politicas con la misma desviacion en mu = 0.5, en tres posiciones de mu."""
    x = np.linspace(0.001, 0.999, 800)
    sigmas, mus = [0.05, 0.1, 0.2, 0.3], [0.15, 0.5, 0.9]
    fig, axes = plt.subplots(len(sigmas), len(mus), figsize=(9.5, 8), sharex=True)
    for r, s in enumerate(sigmas):
        k = kappa_from_sigma(s)
        for c, mu in enumerate(mus):
            ax = axes[r, c]
            g = norm.pdf(x, mu, s)
            ax.plot(x, g, color=TEAL, lw=1.6, label="Gaussiana N(μ, σ²)")
            ax.plot(x, beta_dist.pdf(x, mu * k, (1 - mu) * k), color=AMBER, lw=1.6, label="Beta (κ igualado)")
            lo, hi = norm.cdf(0.02, mu, s), 1 - norm.cdf(1.0, mu, s)       # masa que la gaussiana pierde por el recorte
            txt = []
            if lo > 0.005: txt.append(f"{100*lo:.0f}% → 0.02")
            if hi > 0.005: txt.append(f"{100*hi:.0f}% → 1.0")
            if txt:
                ax.text(0.98 if mu < 0.5 else 0.02, 0.92, "recorte gaussiana:\n" + "\n".join(txt), transform=ax.transAxes,
                        ha="right" if mu < 0.5 else "left", va="top", fontsize=7, color=TEAL)
            sd_b = np.sqrt(mu * (1 - mu) / (k + 1))
            ax.set_title(f"σ = {s}  (κ = {k:.2f}),  μ = {mu}   ·  desv. Beta = {sd_b:.3f}", fontsize=8)
            ax.set_ylim(0, min(ax.get_ylim()[1], 12))
            if r == len(sigmas) - 1: ax.set_xlabel("corriente candidata b = I / Isc")
            if c == 0: ax.set_ylabel("densidad")
    axes[0, 0].legend(fontsize=7, loc="upper right")
    fig.suptitle("Política gaussiana vs Beta con la misma dispersión en μ = 0.5 (κ = 0.25/σ² − 1)", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.97]); fig.savefig(fname, bbox_inches="tight"); plt.close(fig)


def fig_malla(d, fname=f"{OUT}/fig_malla_gauss_beta.png"):
    """Etapa 1: mejor energia (sobre formas/baselines y normalizaciones) en cada celda tasa x sigma, por distribucion."""
    s1 = d["stage1"]
    lrs = [("fixed", 0.1), ("fixed", 0.01), ("fixed", 0.001), ("accel", None), ("inv_t", None)]
    lr_lab = ["fija 0.1", "fija 0.01", "fija 0.001", "acelerada", "1/t"]
    sig = [0.05, 0.1, 0.2, 0.3]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.4), gridspec_kw=dict(wspace=0.38))
    M = {}
    for dist in ("gauss", "beta"):
        A = np.full((len(lrs), len(sig)), np.nan)
        for i, (lr, lv) in enumerate(lrs):
            for j, s in enumerate(sig):
                v = [x["train_energy"] for x in s1 if x["dist"] == dist and x["lr"][0] == lr and (x["lr"][1] == lv) and abs(x["sigma"] - s) < 1e-9]
                A[i, j] = max(v)
        M[dist] = A
    vmin, vmax = min(np.nanmin(a) for a in M.values()), max(np.nanmax(a) for a in M.values())
    for ax, dist in zip(axes, ("gauss", "beta")):
        im = ax.imshow(M[dist], cmap="YlOrBr", vmin=vmin, vmax=vmax, aspect="auto")
        for i in range(len(lrs)):
            for j in range(len(sig)):
                v = M[dist][i, j]
                ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=7.5, color="white" if v > (vmin + 0.65 * (vmax - vmin)) else INK)
        ax.set_xticks(range(len(sig))); ax.set_xticklabels([str(s) for s in sig]); ax.set_yticks(range(len(lrs))); ax.set_yticklabels(lr_lab)
        ax.set_xlabel("σ (dispersión en μ = 0.5)"); ax.set_title(f"{NAME[dist]}: energía % en sombras de entrenamiento"); ax.grid(False)
    fig.colorbar(im, ax=axes, shrink=0.85, label="energía % (mejor forma/baseline y normalización)")
    fig.savefig(fname, bbox_inches="tight"); plt.close(fig)


def _agg(d):
    """energia media por (key, grupo): primero media por escenario (sobre repeticiones), luego media de escenarios."""
    out = {}
    for r in d["test"]:
        out.setdefault((r["key"], r["group"]), {}).setdefault(r["scen"], []).append(r["energy"])
    return {k: float(np.mean([np.mean(v) for v in sc.values()])) for k, sc in out.items()}


def fig_comparacion(d, fname=f"{OUT}/fig_comparacion_gauss_beta.png"):
    a = _agg(d)
    groups = [("static", "4 casos estáticos"), ("pairs", "12 pares reales"), ("synth", "100 sintéticas nuevas")]
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6), sharey=True)
    x = np.arange(len(ARMS)); w = 0.38
    for ax, (g, title) in zip(axes, groups):
        for k, dist in enumerate(("gauss", "beta")):
            vals = [a[(f"{dist}|{arm}", g)] for arm in ARMS]
            ax.bar(x + (k - 0.5) * w, vals, w * 0.92, color=COL[dist], label=NAME[dist])
        ax.axhline(a[("msapso", g)], color=INK, lw=1.2, ls="--", label="MSAPSO fiel")
        ax.set_xticks(x); ax.set_xticklabels([ARM_LABEL[s] for s in ARMS], rotation=35, ha="right", fontsize=7.5)
        ax.set_title(title); ax.set_ylim(80, 100)
    axes[0].set_ylabel("energía entregada (% del techo alcanzable)")
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=3, fontsize=8, frameon=False, bbox_to_anchor=(0.5, 1.04))
    fig.tight_layout(); fig.savefig(fname, bbox_inches="tight"); plt.close(fig)


def fig_trayectoria(d, scen_name="2->4", fname=f"{OUT}/fig_trayectoria_gauss_beta.png"):
    """mu, dispersion y potencia por pasada de la mejor configuracion de cada distribucion en un par real."""
    best = {}
    for dist in ("gauss", "beta"):
        a = _agg(d)
        key = max([f"{dist}|{arm}" for arm in ARMS], key=lambda k: np.mean([a[(k, g)] for g in ("static", "pairs", "synth")]))
        best[dist] = (key, d["chosen"][key])
    scen = dict(build_scenarios(n_synth=1)["pairs"])
    curves = scen[scen_name]
    segs = [(c, PASSES * 7 * WAIT) for c in curves]
    fig, axes = plt.subplots(3, 1, figsize=(8, 6.4), sharex=True)
    for dist, (key, cfg) in best.items():
        kw = dict(dist=cfg["dist"], form=cfg["form"], baseline=cfg["baseline"], lr=cfg["lr"][0], lr_value=cfg["lr"][1] or 0.0,
                  sigma=cfg["sigma"], rnorm=cfg["rnorm"])
        mus, sps = [], []

        def make():
            ctrl = ReinforceDistController(WAIT, rng=np.random.default_rng(777 + zlib.crc32(scen_name.encode()) % 1000), **kw)
            orig = ctrl.step
            def step(plant):
                info = orig(plant); mus.append(ctrl.mu if ctrl.started else np.nan); sps.append(ctrl.spread()); return info
            ctrl.step = step
            return ctrl
        log = run_scenario(make, segs, WAIT)
        k = np.arange(1, len(mus) + 1)
        lab = f"{NAME[dist]} ({ARM_LABEL[key.split('|')[1]]}, σ={cfg['sigma']})"
        axes[0].plot(k, mus, color=COL[dist], lw=1.4, label=lab)
        axes[1].plot(k, sps, color=COL[dist], lw=1.4)
        Pref = np.array([curves[s].P_ceiling for s in log["seg"]])
        axes[2].plot(k, 100 * log["P_end"] / Pref, color=COL[dist], lw=1.0, alpha=0.9)
    ms = run_scenario(lambda: MSAPSOController(WAIT), segs, WAIT)
    Pref = np.array([curves[s].P_ceiling for s in ms["seg"]])
    axes[2].plot(np.arange(1, len(ms["P_end"]) + 1), 100 * ms["P_end"] / Pref, color=GREY, lw=1.0, ls="--", label="MSAPSO fiel")
    for c_i, c in enumerate(curves):
        axes[0].axhline(c.I_ceiling / c.Isc, color=GREEN, lw=0.8, ls=":", xmin=c_i / 2, xmax=(c_i + 1) / 2)
    for ax in axes: ax.axvline(PASSES + 0.5, color=RED, lw=0.9, ls=":")
    axes[0].set_ylabel("μ (media de la política)\nverde = óptimo alcanzable"); axes[1].set_ylabel("desv. estándar\nde la política")
    axes[2].set_ylabel("potencia\n(% del techo)"); axes[2].set_xlabel("pasada (línea roja = cambio de sombra)"); axes[2].set_ylim(30, 105)
    axes[0].legend(fontsize=7, loc="lower right"); axes[2].legend(fontsize=7, loc="lower right")
    fig.suptitle(f"Mejor configuración de cada distribución en el par real {scen_name.replace('->', ' → ')}", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.96]); fig.savefig(fname, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    fig_densidades()
    if os.path.exists(JSON):
        d = json.load(open(JSON))
        fig_malla(d); fig_comparacion(d); fig_trayectoria(d)
    print("figuras listas en", OUT)

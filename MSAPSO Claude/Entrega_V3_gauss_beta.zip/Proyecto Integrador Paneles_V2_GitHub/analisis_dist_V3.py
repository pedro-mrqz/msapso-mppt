"""analisis_dist_V3.py — Tablas y estadistica de REINFORCE gaussiano vs Beta.
Lee resultados_V3/reinforce_dist_grid_V3.json y escribe resultados_V3/analisis_dist_V3.txt (+ .json con las cifras).
Diferencias pareadas por escenario (media de repeticiones por escenario) con IC95 % bootstrap sobre escenarios (10 000 remuestreos)."""
import json, os, sys
import numpy as np

OUT = "resultados_V3"
d = json.load(open(f"{OUT}/reinforce_dist_grid_V3.json"))
ARMS = ["B-none", "B-V", "A-none", "A-V", "A-Q", "A-QV"]
GROUPS = ["static", "pairs", "synth"]
GN = {"static": "4 estáticos", "pairs": "12 pares reales", "synth": "100 sintéticos"}
rng = np.random.default_rng(0)

per = {}   # (key, group) -> {scen: [valores por repeticion]} para cada metrica
for r in d["test"]:
    for m in ("energy", "final", "restarts"):
        per.setdefault((r["key"], r["group"], m), {}).setdefault(r["scen"], []).append(r[m])


def scen_means(key, g, m="energy"):
    s = per[(key, g, m)]
    names = sorted(s)
    return names, np.array([np.mean(s[n]) for n in names])


def mean(key, g, m="energy"):
    return float(scen_means(key, g, m)[1].mean())


def paired(k1, k2, g):
    n1, a = scen_means(k1, g); n2, b = scen_means(k2, g)
    assert n1 == n2
    diff = a - b
    boots = rng.choice(diff, size=(10_000, len(diff)), replace=True).mean(axis=1)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return float(diff.mean()), float(lo), float(hi), int((diff > 0).sum()), len(diff)


lines, summary = [], {"chosen": d["chosen"], "mean": {}, "paired_beta_minus_gauss": {}, "vs_msapso": {}}
P = lambda s="": (print(s), lines.append(s))

P("REINFORCE con politica GAUSSIANA vs BETA — t_wait = 5 ms, mismo simulador, escenarios y protocolo que la V2")
P(f"Etapa 1: {len(d['stage1'])} configuraciones puntuadas en sombras sinteticas de entrenamiento; etapa 2: la mejor de cada (distribucion, forma, baseline).")
P()
P("== Configuracion elegida en la etapa 1 (sin mirar los conjuntos de prueba) ==")
s1 = {(x["dist"], x["form"], x["baseline"], tuple(x["lr"]), x["sigma"], x["rnorm"]): x["train_energy"] for x in d["stage1"]}
for k, c in d["chosen"].items():
    te = s1[(c["dist"], c["form"], c["baseline"], tuple(c["lr"]), c["sigma"], c["rnorm"])]
    lr = c["lr"][0] + ("" if c["lr"][1] is None else f" {c['lr'][1]}")
    P(f"  {k:12s} lr={lr:12s} sigma={c['sigma']:<5} R={c['rnorm']:5s}  energia entrenamiento {te:6.2f}")
P()
P("== Prueba: energia % / potencia final % / reinicios (media por escenario) ==")
P(f"{'metodo':22s}" + "".join(f"{GN[g]:>26s}" for g in GROUPS))
for key in ["msapso"] + [f"{dist}|{a}" for a in ARMS for dist in ("gauss", "beta")]:
    row = f"{('MSAPSO fiel' if key == 'msapso' else key):22s}"
    summary["mean"][key] = {}
    for g in GROUPS:
        e, f, r = mean(key, g), mean(key, g, "final"), mean(key, g, "restarts")
        summary["mean"][key][g] = dict(energy=e, final=f, restarts=r)
        row += f"{e:12.2f} / {f:6.2f} / {r:4.2f}"
    P(row)
P()
P("== Diferencia pareada BETA - GAUSSIANA (puntos de energia; IC95 % bootstrap; Beta mejor en n/N escenarios) ==")
for a in ARMS:
    row = f"{a:8s}"
    summary["paired_beta_minus_gauss"][a] = {}
    for g in GROUPS:
        m, lo, hi, nb, n = paired(f"beta|{a}", f"gauss|{a}", g)
        summary["paired_beta_minus_gauss"][a][g] = dict(diff=m, lo=lo, hi=hi, n_better=nb, n=n)
        row += f"   {g}: {m:+6.2f} [{lo:+6.2f}, {hi:+6.2f}] ({nb}/{n})"
    P(row)
P()
P("== Diferencia pareada contra el MSAPSO fiel (puntos de energia; IC95 %) ==")
for key in [f"{dist}|{a}" for a in ARMS for dist in ("gauss", "beta")]:
    row = f"{key:14s}"
    summary["vs_msapso"][key] = {}
    for g in GROUPS:
        m, lo, hi, nb, n = paired(key, "msapso", g)
        summary["vs_msapso"][key][g] = dict(diff=m, lo=lo, hi=hi, n_better=nb, n=n)
        row += f"   {g}: {m:+6.2f} [{lo:+6.2f}, {hi:+6.2f}]"
    P(row)
P()
P("== Etapa 1: mejor energia de entrenamiento por distribucion y sigma (sobre formas, tasas y normalizaciones) ==")
for dist in ("gauss", "beta"):
    P(f"  {dist:6s} " + "  ".join(f"sigma={s}: {max(x['train_energy'] for x in d['stage1'] if x['dist'] == dist and abs(x['sigma'] - s) < 1e-9):6.2f}"
                                   for s in (0.05, 0.1, 0.2, 0.3)))
P(f"\nTiempo total de la malla: {d['seconds']/60:.1f} min")
open(f"{OUT}/analisis_dist_V3.txt", "w").write("\n".join(lines) + "\n")
json.dump(summary, open(f"{OUT}/analisis_dist_V3.json", "w"), indent=1)

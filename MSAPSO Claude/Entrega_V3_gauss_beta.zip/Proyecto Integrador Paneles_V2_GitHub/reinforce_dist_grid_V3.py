"""
reinforce_dist_grid_V3.py — REINFORCE con politica GAUSSIANA vs BETA (peticion del profesor), mismo protocolo que la V2.

Etapa 1 (seleccion): para cada distribucion, 6 (forma, baseline) x 5 tasas x 4 sigmas x 2 normalizaciones = 240 configuraciones,
  puntuadas con las MISMAS sombras sinteticas de ENTRENAMIENTO de la V2 (semilla 7; 30 pares x 2 repeticiones; energia del 2.o segmento).
  sigma in {0.05, 0.1, 0.2, 0.3}: une la malla de la V2 (0.3) con su extension (0.05-0.2). 0.5 y 0.8 no se incluyen porque una Beta
  no puede tener desviacion >= 0.5 (y en la V2 ya fueron peores que 0.3 para la gaussiana).
Etapa 2 (prueba): la mejor configuracion de cada (distribucion, forma, baseline) se evalua UNA vez en los conjuntos de prueba de la V2
  (4 estaticos, 12 pares reales, 100 sinteticas nuevas; semilla 2026) con 5 repeticiones (2 en sinteticas). Tambien se evalua el MSAPSO
  fiel en los mismos escenarios para las diferencias pareadas.
Semillas: deterministas (zlib.crc32 del nombre del escenario). La V2 usaba hash(name), que Python aleatoriza en cada ejecucion
  (PYTHONHASHSEED), asi que su etapa 2 no es reproducible bit a bit; aqui se corrige.
Salida: resultados_V3/reinforce_dist_grid_V3.json
"""
import json, os, sys, time, zlib, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from multiprocessing import Pool
from pvsim_V2.array_model_V2 import SyntheticPVCurve, random_shading_mix
from pvsim_V2.msapso_V2 import MSAPSOController, run_scenario, segment_metrics
from pvsim_V2.reinforce_dist_V3 import ReinforceDistController
from pvsim_V2.harness_V2 import build_scenarios, PASSES

WAIT = 5e-3
ARMS = [("B", "none"), ("B", "V"), ("A", "none"), ("A", "V"), ("A", "Q"), ("A", "QV")]
LRS = [("fixed", 0.1), ("fixed", 0.01), ("fixed", 0.001), ("accel", None), ("inv_t", None)]
SIGMAS = [0.05, 0.1, 0.2, 0.3]
RNORMS = ["rated", "best"]
DISTS = ["gauss", "beta"]
REPS = {"static": 5, "pairs": 5, "synth": 2}
_TRAIN = None
_SCEN = None


def _init():
    global _TRAIN, _SCEN
    rng = np.random.default_rng(7)  # mismas sombras de entrenamiento que reinforce_grid_V2.py
    _TRAIN = [(SyntheticPVCurve(random_shading_mix(rng)), SyntheticPVCurve(random_shading_mix(rng))) for _ in range(30)]
    _SCEN = build_scenarios()


def _kw(cfg):
    dist, form, base, (lr, lv), sigma, rnorm = cfg
    return dict(dist=dist, form=form, baseline=base, lr=lr, lr_value=(lv if lv is not None else 0.0), sigma=sigma, rnorm=rnorm)


def _score(cfg):
    kw = _kw(cfg)
    vals = []
    for k, (A, B) in enumerate(_TRAIN):
        for rep in range(2):
            segs = [(A, PASSES * 7 * WAIT), (B, PASSES * 7 * WAIT)]
            seed = 10_000 + 17 * k + rep                       # mismas semillas que la V2
            log = run_scenario(lambda: ReinforceDistController(WAIT, rng=np.random.default_rng(seed), **kw), segs, WAIT)
            vals.append(segment_metrics(log, 1)["eff_energy"])
    return cfg, float(np.mean(vals))


def _seed(name, rep):
    return 777 + 31 * rep + zlib.crc32(name.encode()) % 1000


def _test(job):
    key, cfg, g, i, rep = job
    name, curves = _SCEN[g][i]
    segs = [(c, PASSES * 7 * WAIT) for c in curves]
    if cfg is None:                                            # referencia: MSAPSO fiel (determinista)
        log = run_scenario(lambda: MSAPSOController(WAIT), segs, WAIT)
    else:
        kw = _kw(cfg)
        log = run_scenario(lambda: ReinforceDistController(WAIT, rng=np.random.default_rng(_seed(name, rep)), **kw), segs, WAIT)
    m = segment_metrics(log, len(curves) - 1)
    return dict(key=key, group=g, scen=name, rep=rep, energy=m["eff_energy"], final=m["eff_final"],
                restarts=m["n_restarts"], t99=m["t99"])


def cfg_dict(c):
    return dict(dist=c[0], form=c[1], baseline=c[2], lr=list(c[3]), sigma=c[4], rnorm=c[5])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=2)
    ap.add_argument("--out", default="resultados_V3/reinforce_dist_grid_V3.json")
    args = ap.parse_args()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    t0 = time.time()
    grid = [(d, f, b, lr, s, rn) for d in DISTS for (f, b) in ARMS for lr in LRS for s in SIGMAS for rn in RNORMS]
    with Pool(args.procs, initializer=_init) as pool:
        scored = []
        for n, r in enumerate(pool.imap_unordered(_score, grid, chunksize=1), 1):
            scored.append(r)
            if n % 20 == 0:
                print(f"etapa 1: {n}/{len(grid)}  ({time.time()-t0:.0f} s)", flush=True)
        chosen = {}
        for d in DISTS:
            for (f, b) in ARMS:
                best = max([x for x in scored if x[0][0] == d and x[0][1] == f and x[0][2] == b], key=lambda x: x[1])
                chosen[f"{d}|{f}-{b}"] = best[0]
        _init()
        jobs = []
        for key, cfg in list(chosen.items()) + [("msapso", None)]:
            for g in ("static", "pairs", "synth"):
                for i in range(len(_SCEN[g])):
                    for rep in range(REPS[g] if cfg is not None else 1):
                        jobs.append((key, cfg, g, i, rep))
        print(f"etapa 2: {len(jobs)} corridas", flush=True)
        res = list(pool.imap_unordered(_test, jobs, chunksize=4))
    stage1 = [dict(**cfg_dict(c), train_energy=s) for c, s in scored]
    json.dump(dict(stage1=stage1, chosen={k: cfg_dict(v) for k, v in chosen.items()}, test=res,
                   seconds=time.time() - t0), open(args.out, "w"), indent=1, default=float)
    print(f"listo en {time.time()-t0:.0f} s -> {args.out}")

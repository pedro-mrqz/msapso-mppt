"""
reinforce_dist_V3 — Rama REINFORCE con DOS familias de politica: GAUSSIANA (la de la V2) y BETA (pedida por el profesor).

Todo lo demas es IDENTICO a pvsim_V2/reinforce_V2.py (K = 7 candidatos por pasada en por unidad b = I/Isc, escalera
ascendente/descendente alternada, Gbest inmediato, park tras t_max y reinicio si |Pbest - Ppv| >= 5 W, formas A y B,
baselines none | V | Q | QV, tasas fija | accel | inv_t). Solo cambian (1) como se muestrean los candidatos y
(2) la funcion de puntaje (score) d/dmu log pi(b | mu) que usa el gradiente de politica.

GAUSSIANA  b ~ N(mu, sigma^2), recortada a [0.02, 1]          score(b) = (b - mu) / sigma^2
           (se conserva EXACTAMENTE el calculo de la V2: el score se evalua en la muestra ya recortada)

BETA       b ~ Beta(a, c) con a = mu*kappa, c = (1 - mu)*kappa   (parametrizacion media-concentracion; soporte (0, 1))
           score(b) = d/dmu log Beta(b; mu*kappa, (1-mu)*kappa)
                    = kappa * [ ln b - ln(1 - b) - digamma(a) + digamma(c) ]
           La corriente APLICADA se recorta a [0.02, 1] igual que en la gaussiana (mismo limite fisico), pero el score
           se evalua en la muestra SIN recortar, que es la que realmente salio de la politica (estimador sin sesgo).

Comparacion justa: la dispersion se fija con el mismo parametro "sigma" para ambas. Para la Beta se elige kappa de modo
que su desviacion estandar en mu = 0.5 sea igual a sigma:  Var = mu(1-mu)/(kappa+1)  =>  kappa = 0.25/sigma^2 - 1.
Consecuencias que hay que tener presentes al interpretar:
  * Una Beta no puede tener desviacion >= 0.5, asi que sigma solo puede ser < 0.5 (la V2 probo 0.5 y 0.8 en la gaussiana).
  * Con sigma = 0.3 -> kappa = 1.78: en mu = 0.5, a = c = 0.89 < 1 y la densidad es en forma de U (masa en los extremos).
  * Con kappa fijo, la desviacion de la Beta se encoge sola cuando mu se acerca a 0 o a 1 (la gaussiana no).
Para la forma B (la del profesor) el "punto objetivo" es G = Gbest/Isc; con la Beta se recorta G a [0.02, 0.98] para que
ln(1 - G) sea finito.
"""
import numpy as np
from scipy.special import digamma
from pvsim_V2.reinforce_V2 import ReinforceController, P_RATED

B_MIN, B_MAX = 0.02, 1.0        # rango fisico aplicado (igual que la V2)
MU_MAX_BETA = 0.98              # la media de una Beta debe quedar estrictamente dentro de (0, 1)
EPS = 1e-6


def kappa_from_sigma(sigma):
    """Concentracion de la Beta con la misma desviacion que la gaussiana en mu = 0.5."""
    k = 0.25 / sigma ** 2 - 1.0
    if k <= 0:
        raise ValueError(f"sigma = {sigma} no es alcanzable por una Beta (debe ser < 0.5)")
    return k


class ReinforceDistController(ReinforceController):
    """REINFORCE con politica 'gauss' (identica a la V2) o 'beta'."""

    def __init__(self, wait, dist="gauss", **kw):
        super().__init__(wait, **kw)
        self.dist = dist
        if dist == "beta":
            self.kappa = kappa_from_sigma(self.sigma)
        elif dist != "gauss":
            raise ValueError(dist)

    # ---------- politica ----------
    def _mu_max(self):
        return MU_MAX_BETA if self.dist == "beta" else 1.0

    def _sample(self):
        """Devuelve (b_aplicada, b_para_score)."""
        if self.dist == "gauss":
            b = np.clip(self.rng.normal(self.mu, self.sigma, self.K), B_MIN, B_MAX)
            return b, b                                   # V2: score sobre la muestra recortada
        a, c = self.mu * self.kappa, (1.0 - self.mu) * self.kappa
        raw = np.clip(self.rng.beta(a, c, self.K), EPS, 1.0 - EPS)
        return np.clip(raw, B_MIN, B_MAX), raw

    def _score(self, b):
        b = np.asarray(b, dtype=float)
        if self.dist == "gauss":
            return (b - self.mu) / self.sigma ** 2
        a, c = self.mu * self.kappa, (1.0 - self.mu) * self.kappa
        b = np.clip(b, EPS, 1.0 - EPS)
        return self.kappa * (np.log(b) - np.log1p(-b) - digamma(a) + digamma(c))

    def spread(self):
        """Desviacion estandar actual de la politica (por unidad)."""
        if self.dist == "gauss":
            return self.sigma
        return float(np.sqrt(self.mu * (1 - self.mu) / (self.kappa + 1)))

    # ---------- un paso de tiempo (misma estructura que reinforce_V2.step) ----------
    def step(self, plant):
        if not self.started:
            self._restart(plant, first=True)
            self.started = True
        if self.mode == "park":
            P, E = plant.run(self.K * self.wait, self.Gbest)
            restarted = False
            if abs(self.Pbest - P) >= self.thresh:
                self._restart(plant); self.mode = "search"; restarted = True
            return dict(E=E, P_end=P, P_max=P, beta=0.0, mode="park", disp=self.spread(), t=self.t, Gbest=self.Gbest,
                        Pbest=self.Pbest, restart=restarted, mu=self.mu)

        b, b_score = self._sample()
        order = np.argsort(b)
        if self.direction == "descending":
            order = order[::-1]
        P = np.zeros(self.K); E = 0.0
        for i in order:                                                      # escalera
            Pi, e = plant.run(self.wait, b[i] * self.Isc)
            P[i] = Pi; E += e
            if Pi >= self.Pbest:                                             # Gbest inmediato (Ppv >= Pbest)
                self.Pbest, self.Gbest = Pi, plant.Ipv
        Pn = P_RATED if self.rnorm == "rated" else max(self.Pbest, 1e-6)
        R = P / Pn
        lr = self._lr_t()
        V = float(np.mean(self.hist_R)) if self.hist_R else float(R.mean())
        if self.form == "B":
            W = self.Pbest / Pn
            if self.baseline == "V":
                W = W - V
            G = self.Gbest / self.Isc
            if self.dist == "beta":
                G = float(np.clip(G, B_MIN, MU_MAX_BETA))
            d_mu = lr * W * float(self._score(G))
            c = d_mu / (G - self.mu) if abs(G - self.mu) > 1e-9 else 0.0
        else:
            if self.baseline == "none":
                w = R
            elif self.baseline == "V":
                w = R - V
            elif self.baseline == "Q":
                w = R - np.array([self._qhat(bk, V) for bk in b])
            elif self.baseline == "QV":
                w = np.array([self._qhat(bk, V) for bk in b]) - V
            else:
                raise ValueError(self.baseline)
            d_mu = lr * float(np.mean(w * self._score(b_score)))
            c = d_mu / max(abs(float(np.mean(b)) - self.mu), 1e-9)
        self.hist_b.extend(b.tolist()); self.hist_R.extend(R.tolist())
        self.mu = float(np.clip(self.mu + d_mu, B_MIN, self._mu_max()))
        self.c_last = float(c)
        t_now = self.t
        self.t += 1
        self.direction = "descending" if self.direction == "ascending" else "ascending"
        if self.t > self.t_max:
            self.mode = "park"
        return dict(E=E, P_end=float(P[order[-1]]), P_max=float(P.max()), beta=float(lr), mode="search", disp=self.spread(),
                    t=t_now, Gbest=self.Gbest, Pbest=self.Pbest, restart=False, mu=self.mu, c=float(c))
